package wyporzyczalnia;
import java.util.Date;
import java.util.UUID;
import java.util.ArrayList;

public class wyporzyczalnia {
    ArrayList<utwor> zbior;
    ArrayList<uzytkownik> listauzytkownikow;


    public void zaplata(long date1, long date2) {

        long dni = date2 - date1;
        if (dni >= 30) {
            long owed = dni / 100;
            System.out.println("Trzeba zaplacic " + owed + "zł");
        }
}
    public wyporzyczalnia(){
        this.zbior = new ArrayList<>();
        this.listauzytkownikow = new ArrayList<>();
    }
    public void add(plyty x){
        zbior.add(x);
    }
    public void addUser(uzytkownik x){
        listauzytkownikow.add(x);
    }

    public void showwyporzyczalnia() {
        for (utwor x: this.zbior) {
            System.out.println(x.gTYT());
        }
    }
    long wyp(UUID IDu, UUID IDb) {
        uzytkownik user = this.listauzytkownikow.get(0);
        for (uzytkownik x: this.listauzytkownikow) {
            if (x.getID() == IDu) {
                user = x;
            }
        }
        utwor item = this.zbior.get(0);
        for (utwor y: this.zbior){
            if (y.getID() == IDb){
                item = y;
            }
        }
        Date rentDate = new Date();
        long date1= rentDate.getTime();

        user.wypo(IDb);
        item.wyp();
        return date1;
    }
    long zwrot (UUID IDu, UUID IDb){
        uzytkownik user = this.listauzytkownikow.get(0);
        for (uzytkownik x: this.listauzytkownikow) {
            if (x.getID() == IDu) {
                user = x;
            }
        }
        utwor item = this.zbior.get(0);
        for (utwor y: this.zbior){
            if (y.getID() == IDb){
                item = y;
            }
        }
        Date returnDate = new Date();
        long date2= returnDate.getTime();

        user.zwrot(IDb);
        item.zwrot();
        return date2;
    }
}
