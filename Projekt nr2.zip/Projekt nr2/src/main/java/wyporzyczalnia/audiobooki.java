package wyporzyczalnia;

import java.util.Date;

public class audiobooki extends utwor {
    int dlugosc;
    int wielkosc;

    public audiobooki(Date nr_wew, String autor, String wyd, int cena, String tyt, int minutki, int wielkosc) {
        super(nr_wew, autor, wyd, cena, tyt);
        this.dlugosc = minutki;
        this.wielkosc = wielkosc;
    }
}