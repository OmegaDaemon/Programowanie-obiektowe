package wyporzyczalnia;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class Dane {

    String imie;
    String nazwisko;
    String adres;
    int wiek;
    Date dat_zap;
    UUID ID;
    ArrayList<UUID> wyporzyczone;
}
