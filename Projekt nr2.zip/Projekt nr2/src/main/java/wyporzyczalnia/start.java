package wyporzyczalnia;
import java.util.Date;

public class Start {
    public static void main(String[] args) throws Exception {
        wyporzyczalnia Publiczna = new wyporzyczalnia();
        plyty pop = new plyty(new Date(82, 11, 30), "Michael Jackson ", " Epic Records ", 10, "Thriller", 120);
        ksiazki fantastyka = new ksiazki(new Date(94, 00, 00), " Sapkowski ", " Astronomy Today ", 146, " Krew elfów ", 389);
        filmy abc = new filmy(new Date(46, 25, 27), "aaa", "bbb", 36, "abc", 10000);
        audiobooki kkk = new audiobooki(new Date(22, 43, 87), "DD", "FF", 100, "DD", 2, 3);
        Publiczna.add(fantastyka);
        Publiczna.add(pop);
        Publiczna.add(abc);
        Publiczna.add(kkk);
        System.out.println("Zasoby wypożyczalni:");
        Publiczna.showwyporzyczalnia();
        uzytkownik XYZ = new uzytkownik("XYZ", "XYZ", "YXZ", 82);
        Publiczna.addUser(XYZ);
        uzytkownik YXZ = new uzytkownik("YXZ", "YXZ", "ZZZ", 72);
        Publiczna.addUser(YXZ);
        long d1 = Publiczna.wyp(XYZ.getID(), pop.getID());
        XYZ.show();
        Publiczna.wyp(XYZ.getID(), pop.getID());
        Thread.sleep(8000);
        long d2 = Publiczna.zwrot(XYZ.getID(), pop.getID());
        Publiczna.zaplata(d1, d2);

        System.out.println("dane zbiorów:");

        abc.info();
        fantastyka.info();
        pop.info();
        kkk.info();
    }
}